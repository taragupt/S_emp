package pomTest;

import java.io.File;
import java.io.FileInputStream;
//import java.io.FileNotFoundException;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;



public class TestNg {
	
  @Test
  public void f() throws Exception {
	  
	  File src=new File("./configuration/workingwithforms.property");
	  FileInputStream fis=new  FileInputStream(src);
	  Properties pro=new Properties();
	  pro.load(fis);
	  
	  WebDriver driver = new FirefoxDriver();
	  String url=pro.getProperty("url");
	  driver.get(url);
	  
	  driver.findElement(By.id(pro.getProperty("username"))).sendKeys("vineet");
	  Thread.sleep(1000);
	  driver.findElement(By.id(pro.getProperty("password"))).sendKeys("vineet@1234");
	  driver.findElement(By.xpath(pro.getProperty("submit"))).click();
	  
  }
}
