package pomTest;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;

import pom.Firstandlastnamepagefactory;

public class Newtestpagefactory {
  @Test
  public void f1() throws InterruptedException {
	  
	  WebDriver driver = new FirefoxDriver();
	  driver.get("file:///D:/Users/ADM-IG-HWDLAB1B/Desktop/WorkingWithForms.html");
	  
	  Firstandlastnamepagefactory flpg = PageFactory.initElements(driver,Firstandlastnamepagefactory.class) ;
	  flpg.setUname("BINEET");
	 
	  flpg.setPass("bin@1234");
	  flpg.setConpass("bin@123");
		driver.findElement(By.cssSelector("input.Format1")).click();
		 Thread.sleep(1000);
	  System.out.println(driver.switchTo().alert().getText());
		 driver.switchTo().alert().accept();
		 		 
		 flpg.setpwdCpwdAgain("vinnet","vinnet");
		 
		 Thread.sleep(1000);
	  flpg.setLn("JAISWAL");
	  
	  
  }
}
