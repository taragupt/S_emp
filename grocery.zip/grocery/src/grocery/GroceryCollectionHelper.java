package grocery;

import java.util.ArrayList;

public class GroceryCollectionHelper
{
	private  static ArrayList<GroceryDetails> groceryList=new ArrayList<GroceryDetails>();
	
public GroceryCollectionHelper(){}
	
	/*************Add New Grocery in ArrayList************/
	public void addnewgroceryDetails(GroceryDetails grocery) 
	{			
		groceryList.add(grocery);
		System.out.println("Items has been added successfully");
	}
	
	public static ArrayList<GroceryDetails> getgroceryList() {
		return groceryList;
	}

	public static void setbookList(ArrayList<GroceryDetails> groceryList) {
		GroceryCollectionHelper.groceryList = groceryList;
	}

		
}
