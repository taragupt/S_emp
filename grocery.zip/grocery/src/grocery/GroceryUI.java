package grocery;
import java.util.Random;
import java.util.Scanner;

public class GroceryUI 
{

	static Scanner sc=new Scanner(System.in);
	static GroceryCollectionHelper collectionhelper=null;
	
	@SuppressWarnings("static-access")
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int choice=0;
		collectionhelper=new GroceryCollectionHelper();
		
		while(true)
		{
			System.out.println("1:Enter Grocery Details\n"+
					"2:Exit");

			System.out.println("\nEnter your Choice: ");
			choice=sc.nextInt();
			switch(choice)
			{
			case 1:	enterGroceryDetails();
			break;
			case 2: System.exit(0);	
			default: System.out.println("Invalid Choice");
			}
		}
	}
	
	private static void enterGroceryDetails() 
	{
		GroceryDetails grocery=null;
		Random rand=new Random();
		int referenceId=rand.nextInt(1000);
						System.out.println("Enter Grocery Name");
		String groceryName=sc.next();
					if(GroceryValidator.validateGroceryName(groceryName))
			{
			System.out.println("Enter Grocery Type");
			String groceryType=sc.next();
			if(GroceryValidator.validateGroceryType(groceryType))
			{
				System.out.println("Enter Quantity");
				String groceryQuantity =sc.next();
				if(GroceryValidator.validateGroceryQty(groceryQuantity))
				{
						
						 grocery=new GroceryDetails(referenceId, groceryName, groceryType,Integer.parseInt(groceryQuantity));
						 collectionhelper.addnewgroceryDetails(grocery);
				}	
			}
						
		} 
					
System.out.println("Details are:"+grocery.toString());
		
	}
	
	}