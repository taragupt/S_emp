package grocery;
import java.util.regex.Pattern;

public class GroceryValidator
{
	public  static  boolean validateGroceryName(String groceryName)
	{
		String NamePattern="^[A-Za-z]{3,}$";
		if(Pattern.matches(NamePattern, groceryName))
		{
			return true;
		}
		else
		{
			
			System.out.println("Grocery Name should contain minimum 3 letters and alphanumeric");
			return false;
		}
	}
	
	public  static  boolean validateGroceryType(String groceryType)
	{
		String a="Fruit";
		String b="Vegetable";
		String c="Beverages";
		
		if(Pattern.matches(a, groceryType))
		{
			return true;
		}
		else if(Pattern.matches(b, groceryType))
			{
				return true;
			}
		
			else if(Pattern.matches(c, groceryType))
				{
					return true;
				}
		
		else
		{
			System.out.println("Grocery Type sgould be either Fruit or Vegetable or Beverages");
			return false;
		}
	}
	
	public  static  boolean validateGroceryQty(String groceryQuantity)
	{
		String QtyPattern="[0-9]{1,}$";
		if(Pattern.matches(QtyPattern, groceryQuantity))
		{
			return true;
		}
		else
		{
			System.out.println("Grocery Quantity should be a number");
			return false;
		}
	}
}