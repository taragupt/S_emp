package grocery;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import junit.framework.Assert;

public class GroceryCollectionHelperTest {

	static GroceryCollectionHelper collectionHelper;
	static GroceryDetails grocery=null;
	
	@BeforeClass
	public   static  void beforeClass()
	{
		collectionHelper=new GroceryCollectionHelper();
		grocery =new GroceryDetails(1,"Mango","Fruit",5);		
	}
	
	@AfterClass
	public static  void afterClass()
	{		
		collectionHelper=null;
		grocery=null;
	}	
	
		@Test 
	public void addnewgroceryDetails()
	{
		collectionHelper.addnewgroceryDetails(grocery);
		//Assert.assertEquals(4, collectionHelper.getCustList().size());
		Assert.assertNotNull(collectionHelper.toString());
		
	}
	
	}