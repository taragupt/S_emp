package grocery;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class GroceryDetails 

{
	 		private long referenceId;
		private String groceryName;
		private String groceryType;
		private int groceryQuantity;
		
		
		

		GroceryDetails()                           //Default Constructor
		{
			System.out.println("Default Constructor");
		}


		/*public long getReferenceId() {
			return referenceId;
		}*/


		/*public void setReferenceId(long referenceId) {
			this.referenceId = referenceId;
		}*/


		public String getGroceryName() {
			return groceryName;
		}


		public void setGroceryName(String groceryName) {
			this.groceryName = groceryName;
		}


		public String getGroceryType() {
			return groceryType;
		}


		public void setGroceryType(String groceryType) {
			this.groceryType = groceryType;
		}


		public int getGroceryQuantity() {
			return groceryQuantity;
		}


		public void setGroceryQuantity(int groceryQuantity) {
			this.groceryQuantity = groceryQuantity;
		}


		@Override
		public String toString() {
			
			LocalDateTime now= LocalDateTime.now();
			DateTimeFormatter format=	DateTimeFormatter.ofPattern("dd-mm-yyyy HH:MM:SS");
			return "GroceryDetails [referenceId=" + referenceId
					+ ", groceryName=" + groceryName + ", groceryType="
					+ groceryType + ", groceryQuantity=" + groceryQuantity+"Date "+now.format(format)+ "]";
			
		}


		public GroceryDetails(long referenceId, String groceryName,
				String groceryType, int groceryQuantity) {
			super();
			this.referenceId = referenceId;
			this.groceryName = groceryName;
			this.groceryType = groceryType;
			this.groceryQuantity = groceryQuantity;
		}


		
		
		
	}
