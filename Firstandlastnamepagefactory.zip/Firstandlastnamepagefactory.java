package pom;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class Firstandlastnamepagefactory {

	WebDriver driver;
	@FindBy(id="txtUserName")
	@CacheLookup
	WebElement uname;
	

	
	
	@FindBy(id="txtPassword")
	@CacheLookup
	WebElement pass;
	
	@FindBy(id="txtConfPassword")
	@CacheLookup
	WebElement conpass;
	
	@FindBy(how=How.NAME,using="txtLN")
	@CacheLookup
	WebElement ln;
	
	/*@FindBy(xpath="html/head/title")
	@CacheLookup
	WebElement  title;*/
	
	
	

	/*public WebElement getTitle() {
		return title;
	}*/
	



	public Firstandlastnamepagefactory(WebDriver driver) {
		super();
		this.driver = driver;
	}

	public void setUname(String uname) {
		(this.uname).sendKeys(uname);
	}

	public void setLn(String ln) {
		(this.ln).sendKeys(ln);
	}

	public void setPass(String pass) {
		(this.pass).sendKeys(pass);
	}

	public void setConpass(String conpass) {
		(this.conpass).sendKeys(conpass);
	}
	
	
	public void setpwdCpwdAgain(String pwd, String cpwd) {
		this.pass.clear();
		this.conpass.clear();
		
		this.pass.sendKeys(pwd);
		this.conpass.sendKeys(cpwd);
	}
	
	
	
	
	
}
